# Project status and next scientific steps

## Current implementation
- Reduced-order chromium inventory and dissolved-chromium ODE.
- First-order, conservative CsF-like and CsI-like compartment bookkeeping.
- Numerical ODE tests for normalization, inventory monotonicity, and conservation.
- Reproducible Monte Carlo scenario sampling over six illustrative input ranges.
- Blender scripts for creating a conceptual reactor cutaway and animating schematic flow/release markers.

## Not yet completed
- Calibration against a matched, published corrosion experiment.
- Independent validation on a separate experimental condition.
- Experimental uncertainty distributions and parameter correlations.
- Detailed thermodynamic speciation, fluid dynamics, and spatially resolved corrosion.

## Important distinction
Passing software tests verifies selected implementation properties. It does not demonstrate agreement with physical experiments. The Monte Carlo percentiles describe the chosen hypothetical scenario ranges, not the probability of actual reactor outcomes.
