# putting the project on github

1. Make a GitHub account if you do not already have one.
2. Download and unzip this project.
3. Install GitHub Desktop.
4. In GitHub Desktop, choose **File → Add Local Repository**.
5. Select the unzipped `salt-model` folder.
6. If it is not already a repository, choose the option to create one.
7. Name it `salt-model`.
8. Choose whether to make it public or private.
9. Click **Publish repository**.

Before making it public, check that you are happy with the files and that
there are no private details in them.
