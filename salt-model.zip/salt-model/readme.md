# salt model

This is my independent computational project about corrosion and fission-product
transport in molten salt reactors.

I made a small Python model to explore two things:

- chromium leaving an alloy and entering a well-mixed salt
- simple two-compartment transfer for CsF-like and CsI-like tracers

I also made a Blender scene to show the reactor concept and a Monte Carlo script
to see how the model outputs change when the input values are varied.

## files

- `src/msr_model/model.py` - the main model
- `src/msr_model/monte_carlo.py` - runs the scenario analysis
- `src/msr_model/plot_results.py` - makes plots
- `data/parameters.json` - baseline example values
- `results/` - example outputs and plots
- `blender/make_scene.py` - builds and animates the Blender scene
- `tests/` - basic checks for the model
- `docs/` - notes about the methods and results

## run the python model

You need Python 3.10 or newer.

```bash
python -m venv .venv
source .venv/bin/activate
# on windows use: .venv\\Scripts\\activate
pip install -e ".[dev]"
python -m msr_model.model --params data/parameters.json --output results/baseline.csv
python -m msr_model.monte_carlo --n 2000 --seed 20261119 --output-dir results
pytest
```

## use the blender file

1. Open Blender.
2. Go to the Scripting workspace.
3. Open `blender/make_scene.py`.
4. Click Run Script.
5. Save the scene as a new `.blend` file.

The script creates the reactor scene and adds a short looping animation.
Press the space bar to play it.

## important notes

This is a simplified learning model. The input ranges are example scenarios,
not measurements from a real reactor. The Monte Carlo percentiles show the
spread of this chosen set of scenarios; they are not experimental confidence
intervals or predictions.

The corrosion model uses a simplified chromium surface-flux equation. The
CsF-like and CsI-like tracers use simple first-order transfer between two
compartments. They are not detailed chemical-speciation models.

The project does not model neutron transport, fission generation, isotope
decay, fluid dynamics, detailed electrochemistry, cracking, reactor safety,
or component lifetime. The Blender animation is schematic and does not solve
fluid flow.

The tests check selected mathematical properties. Passing tests does not mean
the model has been calibrated or validated against experiments.
